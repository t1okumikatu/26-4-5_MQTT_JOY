# -*- coding: utf-8 -*-
import sys
import os
import math
import threading
import requests
import yaml
import json
from time import sleep, time
import tkinter as tk

# --- 必須ライブラリ ---
import paho.mqtt.client as mqtt

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from rclpy.qos import QoSProfile, ReliabilityPolicy

import robot_2wd_new
import websocket
from enum import Enum, auto

class RobotCmd(Enum):
    DISABLE = auto()
    RUN_FORWARD = auto()
    RUN_BACKWARD = auto()
    RUN_TURN_LEFT = auto()
    RUN_TURN_RIGHT = auto()
    RUN_RPM = auto()
    RUN_STOP = auto()

class RobotController(Node):
    def __init__(self):
        super().__init__('robot_controller')
        
        self.load_config()
        
        self.robot_cmd = RobotCmd.DISABLE
        self.robot_speed_rpm = 1500
        self.rpm_left = 0
        self.rpm_right = 0
        self.last_ws_data_time = 0
        self.is_ws_connected = False
        self.watchdog_count = 0
        self.WATCHDOG_COUNT_MAX = 30 # 通信途絶判定（少し長めに設定）
        
        self.in_zone_1 = self.in_zone_2 = self.in_zone_3 = False
        self.closest_distance = None

        # --- ロボットハードウェア初期化 ---
        try:
            # 指定されたデバイスパスで初期化
            self.robot = robot_2wd_new.Robot2WD(
                "/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_B0001KJH-if00-port0",
                "/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_B003725S-if00-port0"
            )
            self.robot.enable()
            print(">>> Robot Hardware: Connected and Enabled")
        except Exception as e:
            print(f">>> Robot Hardware: Connection Failed ({e})")
            self.robot = None

        # --- MQTT受信設定 (F710ジョイスティック用) ---
        self.mqtt_client = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
        self.mqtt_client.on_message = self.on_mqtt_message
        try:
            # Ubuntu自身のMosquittoに接続
            self.mqtt_client.connect("localhost", 1883, 60)
            self.mqtt_client.subscribe("robot/joystick")
            threading.Thread(target=self.mqtt_client.loop_forever, daemon=True).start()
            print(">>> MQTT Joystick Receiver: Started (Waiting for F710)")
        except Exception as e:
            print(f">>> MQTT Error: {e}")

        # GUIセットアップ (Headless環境でもエラーにならないよう保護)
        self.setup_gui()

        # --- ROS 2 通信設定 ---
        qos_profile = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, depth=10)
        self.subscription = self.create_subscription(LaserScan, '/scan', self.lidar_callback, qos_profile)
        
        # メインループ
        self.create_timer(0.05, self.robot_loop)

    def on_mqtt_message(self, client, userdata, msg):
        """WindowsのF710から届いた信号を解析"""
        try:
            data = json.loads(msg.payload.decode())
            axes = data.get("axes", [])
            
            if len(axes) > 1:
                ly = axes[1] # 前後スティック
                lx = axes[0] # 左右スティック
                
                # スティック入力があれば即座にコマンド更新
                if ly < -0.5: self.robot_cmd = RobotCmd.RUN_FORWARD
                elif ly > 0.5: self.robot_cmd = RobotCmd.RUN_BACKWARD
                elif lx < -0.5: self.robot_cmd = RobotCmd.RUN_TURN_LEFT
                elif lx > 0.5: self.robot_cmd = RobotCmd.RUN_TURN_RIGHT
                else: self.robot_cmd = RobotCmd.RUN_STOP
                
                # 信号が届いているので安全装置をリセット
                self.watchdog_count = 0
        except Exception as e:
            print(f"MQTT Decode Error: {e}")

    def lidar_callback(self, msg):
        self.in_zone_1 = self.in_zone_2 = self.in_zone_3 = False
        angle = msg.angle_min
        for r in msg.ranges:
            if 0.05 < r < 10.0:
                x = r * math.cos(angle); y = r * math.sin(angle)
                if x > 0: # 前方の障害物
                    if x <= 0.22 and abs(y) <= 0.25: self.in_zone_3 = True
                    if x <= 0.55 and abs(y) <= 0.25: self.in_zone_2 = True
                    if x <= 1.05 and abs(y) <= 0.5:  self.in_zone_1 = True
            angle += msg.angle_increment

    def robot_loop(self):
        if not self.robot: return

        # 安全装置: 信号が途絶えたら停止
        if self.watchdog_count > self.WATCHDOG_COUNT_MAX:
            if self.robot_cmd != RobotCmd.DISABLE:
                self.robot.run_stop()
                self.robot_cmd = RobotCmd.DISABLE
            return

        # 衝突防止: 前進中にZone3(22cm以内)に物があれば強制停止
        is_forward = self.robot_cmd in [RobotCmd.RUN_FORWARD, RobotCmd.RUN_TURN_LEFT, RobotCmd.RUN_TURN_RIGHT]
        if is_forward and self.in_zone_3:
            self.robot.run_stop()
        else:
            self.execute_robot_command()
        
        self.watchdog_count += 1

    def execute_robot_command(self):
        speed = self.robot_speed_rpm
        if self.in_zone_2: speed *= 0.25 # 減速
        elif self.in_zone_1: speed *= 0.5 # 減速
        
        if self.robot_cmd == RobotCmd.DISABLE: return
        
        self.robot.enable()
        if self.robot_cmd == RobotCmd.RUN_FORWARD: self.robot.run_straight(speed)
        elif self.robot_cmd == RobotCmd.RUN_BACKWARD: self.robot.run_straight(-speed / 2)
        elif self.robot_cmd == RobotCmd.RUN_TURN_LEFT: self.robot.run_pivot_turn(-speed / 2)
        elif self.robot_cmd == RobotCmd.RUN_TURN_RIGHT: self.robot.run_pivot_turn(speed / 2)
        elif self.robot_cmd == RobotCmd.RUN_STOP:
            self.robot.run_stop()
            self.robot.disable()

    def load_config(self):
        self.half_frontal_angle_rad = math.radians(90) / 2

    def setup_gui(self):
        try:
            self.root = tk.Tk(); self.root.withdraw() # 画面は出さないがイベントループは回す
            self.gui_enabled = True
        except:
            self.gui_enabled = False

    def login_and_connect(self):
        def task():
            try:
                url = 'https://api.avatarchallenge.ca-platform.org/clientLogin/?name=keigan1-ca001&password=eiCa7too&code=keigan1'
                resp = requests.post(url, timeout=5)
                self.info = resp.json(); self.connect_ws()
            except Exception as e:
                print(f"Login failed: {e}. Retrying...")
                sleep(5); self.login_and_connect()
        threading.Thread(target=task, daemon=True).start()

    def connect_ws(self):
        token = self.info['authorisation']['token']
        self.ws = websocket.WebSocketApp(
            f'wss://ws.avatarchallenge.ca-platform.org?token={token}',
            on_message=self.on_ws_message,
            on_open=lambda ws: setattr(self, 'is_ws_connected', True),
            on_close=lambda ws, s, m: setattr(self, 'is_ws_connected', False)
        )
        threading.Thread(target=self.ws.run_forever, daemon=True).start()

    def on_ws_message(self, ws, message):
        """遠隔地(WebSocket)からの命令"""
        ret = message.split(';')
        if len(ret) > 3 and ret[0] == "cmd" and ret[1] == "robot":
            # MQTT(F710)の入力がないときだけ実行するように watchdog を見て判定も可能
            action = ret[3]
            if action == "forward": self.robot_cmd = RobotCmd.RUN_FORWARD
            elif action == "stop": self.robot_cmd = RobotCmd.RUN_STOP
            self.watchdog_count = 0

    def quit_app(self):
        if self.robot: self.robot.run_stop(); self.robot.disable()
        rclpy.shutdown(); sys.exit()

if __name__ == "__main__":
    rclpy.init()
    controller = RobotController()
    controller.login_and_connect()
    
    print(">>> System Ready. Use F710 to move the robot.")
    try:
        rclpy.spin(controller)
    except KeyboardInterrupt: # ←ここ！
        pass
    finally:
        controller.quit_app()